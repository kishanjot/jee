package com.cg.payroll.client;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {
public static void main(String[] args){
		PayrollServices services=new PayrollServicesImpl();
		int associateId1=services.acceptAssociateDetails("Kishanjot", "Singh", "kishanjot@gmail.com", "YTP", "Sr. Consultant","76YPS12" , 4541, 5000, 410, 500, 877725, "Citi", "CITI0005");
		int associateId2=services.acceptAssociateDetails("Honey", "Singh", "honey@gmail.com", "ACC", "Intern","4547we" , 478, 8000, 210, 400, 96665, "Axis", "Axis0005");
		System.out.println("Associate Id"+associateId1);
		System.out.println("\n");
		System.out.println(" Associate Id:"+associateId2);
		//System.out.println(services.getAssociateDetails());
		System.out.println(services.getAllAssociateDetails());
	}
}
