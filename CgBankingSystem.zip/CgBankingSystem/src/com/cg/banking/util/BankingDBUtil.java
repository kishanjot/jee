package com.cg.banking.util;
import java.util.HashMap;
import com.cg.banking.beans.Account;

public class BankingDBUtil {
	public static HashMap<Integer,Account>account=new HashMap<>();
	private static int ACCOUNT_NO_COUNTER=361100045;
	private static int PIN_NO_COUNTER=2454;
	private static String STATUS="ACTIVE";
	
	public static int getACCOUNT_NO_COUNTER() {
		return ++ACCOUNT_NO_COUNTER;
	}
	public static int getPIN_NO() {
			return ++PIN_NO_COUNTER;
	}
	public static String getSTATUS() {
		return STATUS;
	}
	
}
	
