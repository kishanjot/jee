package com.cg.banking.daoservices;

import java.util.List;
import java.util.ArrayList;
import com.cg.banking.beans.Account;
import com.cg.banking.util.BankingDBUtil;


public class AccountDAOImpl implements AccountDAO {

	@Override
	public Account save(Account account) {
		account.setAccountNo(BankingDBUtil.getACCOUNT_NO_COUNTER());
		return account;
	}

	@Override
	public boolean update(Account account) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Account findOne(long accountNo) {
		// TODO Auto-generated method stub
		return BankingDBUtil.account.get(accountNo);
	}

	@Override
	public List<Account> findAll() {
		// TODO Auto-generated method stub
		return new ArrayList<>(BankingDBUtil.account.values());
	}

}
