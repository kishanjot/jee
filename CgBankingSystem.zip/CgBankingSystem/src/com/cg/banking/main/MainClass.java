package com.cg.banking.main;
import java.util.Scanner;

import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args)
	{
		Scanner scan=new Scanner(System.in);
		BankingServices services=new BankingServicesImpl();
	}
}
