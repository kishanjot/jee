import java.util.Scanner;
public class Program1 
{
    
    static String str=" ";
    
    public static void addString(String str)
    {
        String str1=" ";
        System.out.println("Enter String for Concatenation: ");
        Scanner sc=new Scanner(System.in);
        str1=sc.next();
        str+=str1;
        System.out.println(str);
        
    }
    
    public static void replaceOddChar(String str)
    {
        System.out.println("Replace odd char with '#' ");
        int i=0;
        char stringToChar[]=str.toCharArray();
        while(i<stringToChar.length)
        {
            if(i%2==0)
            {
                stringToChar[i]='#';
            }
            i++;
        }
        System.out.println(stringToChar);
    }
    
    public static void removeDuplChar(String str)
    {
        char stringToChar[]=str.toCharArray();
        int charArr[]=new int[100];
        int l=stringToChar.length;
        
        for(int i=0; i<l-1;i++)
        {
            for( int j=i+1;j<l;j++)
            {
                if(stringToChar[i]!=stringToChar[j])
                {
                    continue;
                }
                else
                {
                    charArr[j]=1;
                }
            }
        }
        for(int i=0;i<l;i++)
        {
            if(charArr[i]==0)
            {
                System.out.println(stringToChar[i]);
            }
        }
    }
    
    public static void changeOddChar(String str)
    {
        int i=0;
        char stringToChar[]=str.toCharArray();
        while(i<stringToChar.length)
        {
            if(i%2==0)
            {
                int asc=(int)stringToChar[i];
                asc-=32;
                char ch=(char)asc;
                stringToChar[i]=ch;
            }
            i++;
        }
        System.out.println(stringToChar);
    }
    
    public static void main(String [] args)
    {
        System.out.println("Enter String");
        Scanner sc= new Scanner(System.in);
        str=sc.next();
        System.out.println(str);
        
        System.out.println("Enter your choice");
        System.out.println("1. Concatenation");
        System.out.println("2. Replace Odd Character with '#' ");
        System.out.println("3. Remove Duplicate Character");
        System.out.println("4. Change Odd Character");
        
        int ch=sc.nextInt();
        switch(ch)
        {
        case 1:
            addString(str);
            break;
            
        case 2:
            replaceOddChar(str);
            break;
        case 3:
            removeDuplChar(str);
            break;
        case 4:
            changeOddChar(str);
            break;
        default:
            System.out.println("Wrong Choice:");
            break;
            
        }
    }
          
}