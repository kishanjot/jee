import java.time.LocalDate;
import java.time.Period;
public class Program4 {

    public static void main(String[] args) 
    {
        LocalDate currDate=LocalDate.of(2027,1,20);
        LocalDate userDate= LocalDate.of(2017, 11, 6);
        
        Period p=Period.between(userDate, currDate);
        System.out.println(p.getYears() + "Years," +p.getMonths()+ " Months, and " +p.getDays() + "Days");
    

    }

}