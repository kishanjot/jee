import java.time.LocalDate;


public class Program5 {

    public static void main(String[] args) {
        LocalDate currDate = LocalDate.of(2027, 1, 20);
        LocalDate idnew= currDate.plusYears(2);
        currDate.plusMonths(2);
        System.out.println("Warranty Ends: "+idnew.getMonthValue()+ "/" +idnew.getYear());

    }

}