import java.util.Arrays;
import java.util.Scanner;
public class Program8 
{
    public static void main(String[] args)
    {
        String[] strArr={"i","am","kishanjot","singh","from","chandigarh"};
        Arrays.sort(strArr);
        int strArrLen=strArr.length;
        int halfsize=(strArrLen%2==0) ? strArrLen/2:strArrLen/2+1;
        
        for(int i=0;i<strArrLen;i++)
        {
            strArr[i]=(i<halfsize) ? strArr[i].toUpperCase() : strArr[i].toLowerCase();
        }
        for(int i=0; i<strArrLen; i++)
        {
            System.out.print(strArr[i]+ " ");
        }
    }
    

}