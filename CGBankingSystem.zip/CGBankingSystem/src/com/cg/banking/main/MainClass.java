package com.cg.banking.main;
import java.security.Provider.Service;
import java.util.Scanner;

import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServicesImpl;
public class MainClass {
	public static void main(String args[])
	{
		char continueChoice='y';
		Scanner scan=new Scanner(System.in);
		BankingServicesImpl bankingService=new BankingServicesImpl();
		do{
			{
				System.out.println("BANKING SYSTEM");
				System.out.println("Enter your choice : ");
				System.out.println("Press 1 to open account \n Press 2 to deposit money "
						+ "\n Press 3 to withdraw money \nPress 4 to transfer funds"
						+ " \nPress 5 to get account details"+"\n Press 6 for all transaction details");
				int choice=scan.nextInt();
				switch (choice){
				case 1:{
					try {
						System.out.println("Enter type of account (Savings or current) : ");
						String accountType=scan.next();
						System.out.println("Enter initial balance: ");
						float initialBalance=scan.nextFloat();
						System.out.println(bankingService.openAccount(accountType,initialBalance)); 
						System.out.println("CHECK YOUR ACCOUNT DETAILS ");
					}
					catch(InvalidAmountException e) {
						System.out.println("Amount must be greater than 500");}
					catch(InvalidAccountTypeException e) {
						System.out.println("Account must be savings or current");
					}
					break;
				}
				case 2:{
					System.out.println("Enter your account number:");
					long accNumber=scan.nextLong();
					System.out.println("Enter amount to deposit: ");
					float amt=scan.nextFloat();
					try {
						System.out.println(bankingService.depositAmount(accNumber, amt)+"REMAINING BALANCE"); 
					}
					catch(AccountNotFoundException e) {
						System.out.println("Account not found");
					}
					catch(AccountBlockedException e) {
						System.out.println("Your Account has been blocked. Contact your bank for further details");
					}
					break; 
				}
				case 3: {
					int c=3;
					do {
						System.out.println("Enter your account number:");
						long accNumber=scan.nextLong();
						System.out.println("Enter amount to withdraw: ");
						float amt=scan.nextFloat();
						System.out.println("Enter pin: ");
						int pinNumber=scan.nextInt();
						try {
							System.out.println(bankingService.withdrawAmount(accNumber, amt,pinNumber)+"REMAINING BALANCE ");
							c=-1;}
						catch(AccountNotFoundException e) {
							System.out.println("Account Not found. Please enter valid account number");
						}
						catch(InvalidPinNumberException e) {
							--c;
							try {
								bankingService.checkPin(c, accNumber);
							}
							catch(AccountBlockedException e1) {
								System.out.println("Account blocked");
								//System.exit(0);
								break;
							}
							System.out.println("Enter valid pin number");
						}
						catch(AccountBlockedException e) {
							System.out.println("Your account has been blocked");
						}
						catch(InsufficientAmountException e) {
							System.out.println("Insuffiicient amount in your account");
						}
					}
					while(c>0);
					break; }
				case 4:
					int c=3;
					do { 
						System.out.println("Enter your account number: ");
						long fromAcc=scan.nextLong();
						System.out.println("Enter account number to deposit: ");
						long toAcc=scan.nextLong();
						System.out.println("Enter amount: ");
						float transfer=scan.nextFloat();
						System.out.println("Enter pin : ");
						int pinNumber=scan.nextInt();
						try {
							bankingService.fundTransfer(toAcc, fromAcc, transfer, pinNumber);
							c=-1;
						}
						catch(AccountNotFoundException e) {
							System.out.println("Account Not found. Please enter valid account number");
						}
						catch(AccountBlockedException e) {
							System.out.println("Your Account has been blocked. Contact your bank for further details");
						}
						catch(InvalidPinNumberException e) {
							--c;
							try {
								bankingService.checkPin(c, fromAcc);
							}
							catch(AccountBlockedException e1) {
								System.out.println("Account blocked");
								//System.exit(0);
								break;
							}
							System.out.println("Enter valid pin number");

						}
						catch(InsufficientAmountException e) {
							System.out.println("Insuffiicient amount in your account");
						}
					}
					while(c>0);
					break;
				case 5:
					try {
						System.out.println("Enter your account number:");
						long accNumber=scan.nextLong();
						System.out.println(bankingService.getAccountDetails(accNumber)); }
					catch(AccountNotFoundException e) {
						System.out.println("Account not found");
					}
					break;
				case 6:
				{
					try {
						System.out.println("Enter your account number: ");
						long accNumber=scan.nextLong();
						System.out.println(bankingService.getAccountAllTransaction(accNumber)); 
					}
					catch(AccountNotFoundException e) {
						System.out.println("Account not found");
					}
				}
				break;
				default:
					System.out.println("Wrong choice");
				}
				System.out.println("Do you want to continue (y or n): ");
				continueChoice=scan.next().charAt(0);
			}
		}
		while(continueChoice=='y'||continueChoice=='Y');
	}
}   


